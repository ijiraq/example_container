/* XPM */
static char * diamond1 [] = {
/* width height ncolors cpp [x_hot y_hot] */
"17 17 4 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s bottomShadowColor	m black	c #646464646464",
"X	s foreground	m white	c white",
"o	s topShadowColor	m white	c #c8c8c8c8c8c8",
/* pixels */
"                 ",
"       ...       ",
"      ..X..      ",
"     ..XXX..     ",
"    ..XXXXX..    ",
"   ..XXXXXXX..   ",
"  ..XXXXXXXXX..  ",
" ..XXXXXXXXXXX.. ",
" .XXXXXXXXXXXXX. ",
" ooXXXXXXXXXXXoo ",
"  ooXXXXXXXXXoo  ",
"   ooXXXXXXXoo   ",
"    ooXXXXXoo    ",
"     ooXXXoo     ",
"      ooXoo      ",
"       ooo       ",
"                 "};
