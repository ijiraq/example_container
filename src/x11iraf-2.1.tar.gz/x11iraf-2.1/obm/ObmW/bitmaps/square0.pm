/* XPM */
static char * square0 [] = {
/* width height ncolors cpp [x_hot y_hot] */
"15 15 3 1 0 0",
/* colors */
" 	s topShadowColor	m white	c #c8c8c8c8c8c8",
".	s bottomShadowColor	m black	c #646464646464",
"X	s none	m none	c none",
/* pixels */
"               ",
"              .",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  XXXXXXXXXXX..",
"  .............",
" .............."};
