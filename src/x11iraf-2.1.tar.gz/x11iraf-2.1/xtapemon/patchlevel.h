/*
 * patchlevel.h : xtapemon version control
 */

int xtapemonMajorVersion = 1;
int xtapemonMinorVersion = 0;
