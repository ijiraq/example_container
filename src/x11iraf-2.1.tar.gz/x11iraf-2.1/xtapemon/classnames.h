/*
 * classnames.h : External defs for the classname converter
 *
 * George Ferguson, ferguson@cs.rochester.edu, 4 Sep 1991.
 *
 */

extern WidgetClass classNameToWidgetClass(/* name,isShellp */);
